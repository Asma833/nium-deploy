export const viewAllTableData = [
    {
      nium_order_id: "N-001",
      createdAt: "18.02.2025",
      partner_order_id:"1234",
      customer_pan: "AFJPW0198D",
      transaction_type: "Card Load VKYC + ESign",
      purpose_type: "BTQ",
      e_sign_status: "Pending",
      e_sign_customer_completion_date:"06-02-2025 18:47:37 IST",
      v_kyc_status: "Success",
      v_kyc_customer_completion_date:"06-02-2025 18:47:37 IST",
      incident_status: "pending",
      incident_completion_date:"06-02-2025 18:47:37 IST",
    },
    {
      nium_order_id: "N-002",
      createdAt: "20.03.2025",
      partner_order_id:"1234",
      customer_pan: "AFJPW0198D",
      transaction_type: "Card Load VKYC + ESign",
      purpose_type: "BTQ",
      e_sign_status: "Pending",
      e_sign_customer_completion_date:"06-02-2025 18:47:37 IST",
      v_kyc_status: "Success",
      v_kyc_customer_completion_date:"06-02-2025 18:47:37 IST",
      incident_status: "pending",
      incident_completion_date:"06-02-2025 18:47:37 IST",
    },
   
  ];
  