export const getTransactionTableColumns = () => [
    {
      key: "nium_order_id",
      id: "nium_order_id",
      name: "Nium ID",
      cell: (value: string) => (
        <span
          className="text-pink-600"
        >
          {value}
        </span>
      ),
    },
    {
      key: "createdAt",
      id: "createdAt",
      name: "Order Date",
    },
    {
      key: "partner_order_id",
      id: "partner_order_id",
      name: "Agent ID",
    },
    {
      key: "customer_pan",
      id: "customer_pan",
      name: "Customer PAN",
    },
    {
      key: "transaction_type",
      id: "transaction_type",
      name: "Transaction Type",
    },
    {
      key: "purpose_type",
      id: "purpose_type",
      name: "Purpose Type",
    },
    {
      key: "e_sign_status",
      id: "e_sign_status",
      name: "E-Sign Status",
    },
    {
      key: "e_sign_customer_completion_date",
      id: "e_sign_customer_completion_date",
      name: "E-Sign Status Completion Date",
    },
    {
      key: "v_kyc_status",
      id: "v_kyc_status",
      name: "VKYC Status",
    },
    {
      key: "v_kyc_customer_completion_date",
      id: "v_kyc_customer_completion_date",
      name: "VKYC Completion Date",
    },
    {
      key: "incident_status",
      id: "incident_status",
      name: "Incident Status",
    },
    {
      key: "incident_completion_date",
      id: "incident_completion_date",
      name: "Incident Completion Date",
    },
    {
      key: "nium_invoice_number",
      id: "nium_invoice_number",
      name: "NIUM INVOICE NUMBER",
    },
  ];
  